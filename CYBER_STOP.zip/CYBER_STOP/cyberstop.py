#!/usr/bin/env python3
"""
 ██████╗██╗   ██╗██████╗ ███████╗██████╗ ███████╗████████╗ ██████╗ ██████╗
██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗
██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝███████╗   ██║   ██║   ██║██████╔╝
██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗╚════██║   ██║   ██║   ██║██╔═══╝
╚██████╗   ██║   ██████╔╝███████╗██║  ██║███████║   ██║   ╚██████╔╝██║
 ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝
"""

import os
import sys
import importlib
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

REAPER = r"""
                                    _.--'"""`--.._
                               _.--'              `--.._
                           _.--'                        `--.
                       _.--'             ,..               `-.
                   _.--'            ,.-'     `-.              `--._
               _.--'            .-'             `.                 `-.
           _.--'             .-'                  \                   `--._
          /              _..-'                     \                       `\
         /          _..-'                           |                        |
        |        .-'                               /                         |
        |      .'                              _.-'                         /
        |    .'                           _.--'                             |
        |   /                        _.--'                                  |
        |  |                    _.--'                                      /
        | |                 _.-'                  __....----''''''''       |
        | |             _.-'            __....----'                  `--...|
        | |         _.-'     __....----'               .-.                 |
        | |      .-'   ___.-'                        /   `\                |
        | |   .-' _.-'                              / /`-. \               |
        | | .' .-'                                 | |   | |               |
         \|  /.'          ████████╗██╗  ██╗███████╗| |   | |              /
          |  /            ╚══██╔══╝██║  ██║██╔════╝ \ \.-' /             /
          | |                ██║   ███████║█████╗    `-----'             |
          | |                ██║   ██╔══██║██╔══╝                        |
          |  \               ██║   ██║  ██║███████╗                     /
           \  `-.            ╚═╝   ╚═╝  ╚═╝╚══════╝                   /
            `-   `-.                                                 .-'
              `-.   `-.                                           .-'
                 `-.   `-._                                   _.-'
                    `-._   `--.._                       __.-'
                        `--.._   `""--..______..--""`.-'
                              `""--..____________..-'

                     ☠  REAP WHAT THEY HIDE  ☠
"""

DISCLAIMER = """
╔══════════════════════════════════════════════════════════════╗
║              ⚠  LEGAL DISCLAIMER & ETHICS NOTICE  ⚠         ║
║                                                              ║
║  CyberStop is for AUTHORIZED testing and EDUCATIONAL use.   ║
║  Unauthorized use against systems/persons you do NOT have   ║
║  explicit permission to test is ILLEGAL under:              ║
║   • Computer Fraud and Abuse Act (CFAA)                     ║
║   • Computer Misuse Act (UK)                                ║
║   • GDPR and local privacy laws                             ║
║                                                              ║
║  The authors assume NO liability for misuse of this tool.   ║
║  You are solely responsible for your actions.               ║
╚══════════════════════════════════════════════════════════════╝
"""

MODULE_CATEGORIES = {
    "OSINT / Reconnaissance": [
        "ip_geo", "username_search", "email_breach", "phone_lookup",
        "domain_whois", "dns_enum", "subdomain_enum", "wayback_urls",
        "dox_tool",
    ],
    "Network / Infrastructure": [
        "port_scan", "ping_sweep", "traceroute_tool",
        "http_headers", "ssl_analyzer", "asn_lookup",
    ],
    "Web Application Testing": [
        "cms_fingerprint", "waf_detect", "git_finder",
    ],
    "Password & Crypto Tools": [
        "password_gen", "hash_gen", "base64_tool",
        "xor_cipher", "password_strength",
    ],
    "Malware / Forensics": [
        "file_hasher", "exif_extractor", "strings_extractor",
    ],
    "Utility / Productivity": [
        "wordlist_gen", "payload_encoder", "reverse_shell_gen",
        "base_converter", "report_saver",
    ],
}

try:
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    CYAN    = "\033[96m"
    MAGENTA = "\033[95m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RESET   = "\033[0m"
    try:
        import colorama
        colorama.init(autoreset=True)
    except ImportError:
        pass
except Exception:
    RED = GREEN = YELLOW = CYAN = MAGENTA = BOLD = DIM = RESET = ""


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def print_banner():
    clear_screen()
    print(f"{RED}{REAPER}{RESET}")
    print(f"{RED}{DISCLAIMER}{RESET}")


def load_modules():
    modules_dir = Path(__file__).parent / "modules"
    loaded = {}
    for mod_name in [m for cat in MODULE_CATEGORIES.values() for m in cat]:
        try:
            mod = importlib.import_module(f"modules.{mod_name}")
            if hasattr(mod, "name") and hasattr(mod, "run"):
                loaded[mod_name] = mod
        except Exception as e:
            print(f"{YELLOW}[!]{RESET} Failed to load module '{mod_name}': {e}")
    return loaded


def print_menu(loaded_modules):
    print(f"\n{CYAN}{'═'*64}{RESET}")
    print(f"{CYAN}{BOLD}{'  CYBERSTOP — MODULE MENU':^64}{RESET}")
    print(f"{CYAN}{'═'*64}{RESET}\n")

    counter = 1
    index_map = {}

    for category, mod_names in MODULE_CATEGORIES.items():
        print(f"  {MAGENTA}{BOLD}[ {category} ]{RESET}")
        for mod_name in mod_names:
            if mod_name in loaded_modules:
                mod = loaded_modules[mod_name]
                index_map[str(counter)] = mod_name
                print(f"    {CYAN}[{counter:>2}]{RESET}  {mod.name}")
                counter += 1
            else:
                print(f"    {DIM}[--]{RESET}  {DIM}{mod_name.replace('_',' ').title()} (not loaded){RESET}")
        print()

    print(f"  {YELLOW}[ 0 ]{RESET}  Exit\n")
    print(f"{CYAN}{'─'*64}{RESET}")
    return index_map


def module_banner(mod):
    print(f"\n{CYAN}{'='*64}{RESET}")
    print(f"{CYAN}{BOLD}  ☠  {mod.name.upper()}{RESET}")
    print(f"{CYAN}{'='*64}{RESET}\n")


def main():
    print_banner()
    input(f"  {YELLOW}Press ENTER to continue...{RESET}")

    loaded_modules = load_modules()

    while True:
        print_banner()
        index_map = print_menu(loaded_modules)

        try:
            choice = input(f"  {CYAN}Select module {RESET}[0-{len(index_map)}]{CYAN} > {RESET}").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n  {RED}Goodbye, ghost.{RESET}\n")
            sys.exit(0)

        if choice == "0":
            print(f"\n  {RED}Goodbye, ghost.{RESET}\n")
            sys.exit(0)

        if choice not in index_map:
            print(f"\n  {YELLOW}[!]{RESET} Invalid selection. Try again.")
            input(f"  {DIM}Press ENTER to continue...{RESET}")
            continue

        mod_name = index_map[choice]
        mod = loaded_modules[mod_name]

        print_banner()
        module_banner(mod)

        try:
            mod.run()
        except KeyboardInterrupt:
            print(f"\n\n  {YELLOW}[!]{RESET} Module interrupted.")
        except Exception as e:
            print(f"\n  {RED}[-]{RESET} Unexpected error in module: {e}")
            if os.environ.get("CYBERSTOP_DEBUG"):
                traceback.print_exc()

        try:
            input(f"\n  {DIM}Press ENTER to return to menu...{RESET}")
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n  {RED}Goodbye, ghost.{RESET}\n")
            sys.exit(0)


if __name__ == "__main__":
    main()
