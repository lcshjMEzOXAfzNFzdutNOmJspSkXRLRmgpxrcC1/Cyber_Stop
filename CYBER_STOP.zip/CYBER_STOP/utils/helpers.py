import os
import re
import sys
import json
import datetime
from pathlib import Path

REPORTS_DIR = Path(__file__).resolve().parent.parent / "reports"


def ensure_dir(path=None):
    p = Path(path) if path else REPORTS_DIR
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_output(content, default_name="output"):
    ensure_dir()
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = input(f"  Save as (default: {default_name}_{timestamp}.txt): ").strip()
    if not filename:
        filename = f"{default_name}_{timestamp}.txt"
    if not filename.endswith((".txt", ".json", ".csv", ".html")):
        filename += ".txt"
    filepath = REPORTS_DIR / filename
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    return str(filepath)


def copy_to_clipboard(text):
    try:
        import pyperclip
        pyperclip.copy(text)
        return True
    except Exception:
        return False


def validate_ip(ip):
    pattern = r"^(\d{1,3}\.){3}\d{1,3}$"
    if re.match(pattern, ip):
        parts = ip.split(".")
        return all(0 <= int(p) <= 255 for p in parts)
    return False


def validate_domain(domain):
    pattern = r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
    return bool(re.match(pattern, domain))


def validate_email(email):
    pattern = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
    return bool(re.match(pattern, email))


def prompt_save(content, default_name="result"):
    try:
        save = input("\n  Save output to file? [y/N]: ").strip().lower()
        if save == "y":
            path = save_output(content, default_name)
            from utils.colors import success
            success(f"Saved to: {path}")
        clip = input("  Copy to clipboard? [y/N]: ").strip().lower()
        if clip == "y":
            ok = copy_to_clipboard(content)
            from utils.colors import success, error
            if ok:
                success("Copied to clipboard.")
            else:
                error("pyperclip not installed. Run: pip install pyperclip")
    except KeyboardInterrupt:
        pass


def get_input(prompt, required=True):
    while True:
        try:
            val = input(f"  {prompt}: ").strip()
        except KeyboardInterrupt:
            print()
            return None
        if val:
            return val
        if not required:
            return ""
        from utils.colors import warn
        warn("Input cannot be empty.")


def http_get(url, timeout=10, headers=None):
    try:
        import requests
        h = {"User-Agent": "Mozilla/5.0 (CyberStop/1.0)"}
        if headers:
            h.update(headers)
        r = requests.get(url, timeout=timeout, headers=h, allow_redirects=True)
        return r
    except Exception as e:
        return None


def progress_bar(iterable, prefix="Progress", length=40):
    try:
        from tqdm import tqdm
        return tqdm(iterable, desc=prefix, ncols=80)
    except ImportError:
        return iterable
