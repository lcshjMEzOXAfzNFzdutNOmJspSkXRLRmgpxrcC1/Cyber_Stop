import sys

try:
    import colorama
    colorama.init(autoreset=True)
    COLORAMA = True
except ImportError:
    COLORAMA = False

RED     = "\033[91m"
GREEN   = "\033[92m"
YELLOW  = "\033[93m"
BLUE    = "\033[94m"
MAGENTA = "\033[95m"
CYAN    = "\033[96m"
WHITE   = "\033[97m"
BOLD    = "\033[1m"
DIM     = "\033[2m"
RESET   = "\033[0m"

def red(text):     return f"{RED}{text}{RESET}"
def green(text):   return f"{GREEN}{text}{RESET}"
def yellow(text):  return f"{YELLOW}{text}{RESET}"
def blue(text):    return f"{BLUE}{text}{RESET}"
def magenta(text): return f"{MAGENTA}{text}{RESET}"
def cyan(text):    return f"{CYAN}{text}{RESET}"
def white(text):   return f"{WHITE}{text}{RESET}"
def bold(text):    return f"{BOLD}{text}{RESET}"
def dim(text):     return f"{DIM}{text}{RESET}"

def banner(text, color=CYAN):
    line = "=" * 60
    print(f"{color}{line}{RESET}")
    print(f"{color}{BOLD}  {text}{RESET}")
    print(f"{color}{line}{RESET}")

def section(text):
    print(f"\n{CYAN}[*]{RESET} {BOLD}{text}{RESET}")

def success(text):
    print(f"{GREEN}[+]{RESET} {text}")

def warn(text):
    print(f"{YELLOW}[!]{RESET} {text}")

def error(text):
    print(f"{RED}[-]{RESET} {text}")

def info(text):
    print(f"{BLUE}[i]{RESET} {text}")
