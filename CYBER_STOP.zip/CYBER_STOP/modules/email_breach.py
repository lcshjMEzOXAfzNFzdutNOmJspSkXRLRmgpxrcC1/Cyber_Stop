name = "Email Breach Check"

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, validate_email, prompt_save, http_get

    banner("EMAIL BREACH CHECK", CYAN)
    print(f"  {CYAN}Check HaveIBeenPwned for data breaches linked to an email.{RESET}\n")

    email = get_input("Enter email address")
    if email is None:
        return

    if not validate_email(email):
        warn("That doesn't look like a valid email address.")

    section("Checking HaveIBeenPwned API v3...")
    url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}?truncateResponse=false"
    headers = {
        "User-Agent": "CyberStop-OSINT-Tool/1.0",
        "hibp-api-key": "anonymous",
    }

    try:
        import requests
        r = requests.get(url, timeout=10, headers=headers)
    except Exception as e:
        error(f"Network error: {e}")
        return

    lines = [f"EMAIL BREACH CHECK: {email}", "=" * 50]

    if r.status_code == 404:
        success(f"No breaches found for: {email}")
        lines.append("No breaches found. Email appears clean.")
        prompt_save("\n".join(lines), "email_breach")
        return

    if r.status_code == 401:
        warn("HIBP API key required for full results (API changed policy).")
        info("Visit: https://haveibeenpwned.com/API/v3")
        section("Attempting public check via HIBP website scrape...")

        alt_r = http_get(f"https://haveibeenpwned.com/{email}")
        if alt_r and "Oh no" in alt_r.text:
            error(f"Email {email} has been found in breaches!")
            lines.append("Status: FOUND IN BREACHES (public check)")
        else:
            info("Could not determine breach status without API key.")
            lines.append("Status: UNKNOWN (API key required)")
        prompt_save("\n".join(lines), "email_breach")
        return

    if r.status_code == 200:
        try:
            breaches = r.json()
        except Exception:
            error("Failed to parse response.")
            return

        error(f"PWNED! Found in {len(breaches)} breach(es):")
        lines.append(f"Status: PWNED - Found in {len(breaches)} breach(es)")
        lines.append("")
        for b in breaches:
            print(f"\n  {RED}Breach:{RESET} {b.get('Name', 'Unknown')}")
            print(f"    {YELLOW}Date:{RESET}    {b.get('BreachDate', 'N/A')}")
            print(f"    {YELLOW}Domain:{RESET}  {b.get('Domain', 'N/A')}")
            classes = ", ".join(b.get("DataClasses", []))
            print(f"    {YELLOW}Data:{RESET}    {classes}")
            lines.append(f"Breach: {b.get('Name')} | Date: {b.get('BreachDate')} | Data: {classes}")
    else:
        warn(f"Unexpected status code: {r.status_code}")
        lines.append(f"Status: Error {r.status_code}")

    prompt_save("\n".join(lines), "email_breach")
