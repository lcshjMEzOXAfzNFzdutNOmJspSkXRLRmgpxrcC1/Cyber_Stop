name = "Traceroute"

import subprocess
import platform

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save, http_get

    banner("TRACEROUTE", CYAN)
    print(f"  {CYAN}Trace the network path to a host with hop geolocation.{RESET}\n")

    target = get_input("Enter target hostname or IP")
    if target is None:
        return

    section(f"Tracing route to {target}...")
    is_win = platform.system().lower() == "windows"
    cmd = ["tracert", "-d", target] if is_win else ["traceroute", "-n", target]

    lines = [f"TRACEROUTE: {target}", "=" * 50]

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        hop_ips = []
        for line in proc.stdout:
            line = line.rstrip()
            print(f"  {line}")
            lines.append(line)
            import re
            ips = re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", line)
            for ip in ips:
                if ip not in ("0.0.0.0", "255.255.255.255"):
                    hop_ips.append(ip)
        proc.wait()

        if hop_ips:
            section("Hop Geolocation")
            for ip in hop_ips[:15]:
                r = http_get(f"http://ip-api.com/json/{ip}?fields=status,city,country,isp", timeout=5)
                if r:
                    try:
                        d = r.json()
                        if d.get("status") == "success":
                            print(f"  {GREEN}{ip:<18}{RESET} {d.get('city','?')}, {d.get('country','?')} | {d.get('isp','?')}")
                            lines.append(f"{ip}: {d.get('city')}, {d.get('country')} | {d.get('isp')}")
                    except Exception:
                        pass

    except FileNotFoundError:
        warn(f"'{cmd[0]}' not found. Trying alternative...")
        try:
            import socket
            addr = socket.gethostbyname(target)
            info(f"Resolved: {target} -> {addr}")
        except Exception as e:
            error(f"Could not resolve target: {e}")
    except Exception as e:
        error(f"Traceroute failed: {e}")

    prompt_save("\n".join(lines), "traceroute")
