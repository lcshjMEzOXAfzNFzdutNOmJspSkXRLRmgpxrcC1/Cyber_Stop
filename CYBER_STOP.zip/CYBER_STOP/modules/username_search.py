name = "Username Search"

PLATFORMS = [
    ("GitHub",        "https://github.com/{}"),
    ("Twitter/X",     "https://twitter.com/{}"),
    ("Reddit",        "https://reddit.com/user/{}"),
    ("Instagram",     "https://instagram.com/{}"),
    ("TikTok",        "https://tiktok.com/@{}"),
    ("YouTube",       "https://youtube.com/@{}"),
    ("LinkedIn",      "https://linkedin.com/in/{}"),
    ("Pinterest",     "https://pinterest.com/{}"),
    ("Tumblr",        "https://{}.tumblr.com"),
    ("Medium",        "https://medium.com/@{}"),
    ("Dev.to",        "https://dev.to/{}"),
    ("Twitch",        "https://twitch.tv/{}"),
    ("Steam",         "https://steamcommunity.com/id/{}"),
    ("Patreon",       "https://patreon.com/{}"),
    ("Spotify",       "https://open.spotify.com/user/{}"),
    ("SoundCloud",    "https://soundcloud.com/{}"),
    ("Flickr",        "https://flickr.com/people/{}"),
    ("Vimeo",         "https://vimeo.com/{}"),
    ("Keybase",       "https://keybase.io/{}"),
    ("GitLab",        "https://gitlab.com/{}"),
    ("BitBucket",     "https://bitbucket.org/{}"),
    ("Replit",        "https://replit.com/@{}"),
    ("HackerNews",    "https://news.ycombinator.com/user?id={}"),
    ("ProductHunt",   "https://producthunt.com/@{}"),
    ("Quora",         "https://quora.com/profile/{}"),
    ("Fiverr",        "https://fiverr.com/{}"),
    ("Etsy",          "https://etsy.com/shop/{}"),
    ("Behance",       "https://behance.net/{}"),
    ("Dribbble",      "https://dribbble.com/{}"),
    ("CodePen",       "https://codepen.io/{}"),
]

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, prompt_save, progress_bar
    import threading

    banner("USERNAME SEARCH", CYAN)
    print(f"  {CYAN}Probe {len(PLATFORMS)} platforms for a username.{RESET}\n")

    username = get_input("Enter username")
    if username is None:
        return

    section(f"Searching for: {username}")

    found = []
    not_found = []
    errors = []
    results_lock = threading.Lock()

    def check(platform, url_template):
        try:
            import requests
            url = url_template.format(username)
            r = requests.get(url, timeout=8, allow_redirects=True,
                             headers={"User-Agent": "Mozilla/5.0"})
            with results_lock:
                if r.status_code == 200:
                    found.append((platform, url))
                    print(f"  {GREEN}[FOUND]{RESET}   {platform:<20} {url}")
                elif r.status_code == 404:
                    not_found.append((platform, url))
                else:
                    errors.append((platform, url, r.status_code))
        except Exception as e:
            with results_lock:
                errors.append((platform, url_template.format(username), str(e)))

    threads = []
    for platform, url_template in PLATFORMS:
        t = threading.Thread(target=check, args=(platform, url_template), daemon=True)
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print(f"\n  {GREEN}Found: {len(found)}{RESET}  |  Not Found: {len(not_found)}  |  Errors: {len(errors)}")

    lines = [f"USERNAME SEARCH: {username}", "=" * 50]
    for platform, url in found:
        lines.append(f"[FOUND] {platform}: {url}")
    if not_found:
        lines.append("\n[NOT FOUND]")
        for platform, url in not_found:
            lines.append(f"  {platform}: {url}")

    prompt_save("\n".join(lines), "username_search")
