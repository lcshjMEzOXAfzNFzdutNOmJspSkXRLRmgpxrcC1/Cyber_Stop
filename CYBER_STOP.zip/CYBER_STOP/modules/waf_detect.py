name = "WAF Detection"

WAF_SIGNATURES = {
    "Cloudflare":      ["__cfduid", "cf-ray", "cloudflare", "cf-cache-status"],
    "AWS WAF":         ["x-amzn-requestid", "awselb", "x-amz-cf-id"],
    "Akamai":          ["akamai", "x-akamai-transformed", "akamaighost"],
    "Sucuri":          ["x-sucuri-id", "sucuri", "x-sucuri-cache"],
    "Imperva/Incapsula":["x-iinfo", "incap_ses", "_incap_"],
    "F5 BIG-IP":       ["bigipservercookie", "f5_cspm", "ts0"],
    "ModSecurity":     ["mod_security", "modsecurity", "mod_sec"],
    "Barracuda":       ["barra_counter_session", "bn-lb"],
    "Citrix NetScaler":["ns_af", "citrix_ns_id"],
    "Fortinet":        ["fortigate", "fortiwaf"],
    "DenyAll":         ["sessioncookie"],
    "Radware AppWall": ["rdwr_id"],
}

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, prompt_save, http_get

    banner("WAF DETECTION", CYAN)
    print(f"  {CYAN}Identify Web Application Firewalls by fingerprinting headers and behavior.{RESET}\n")

    url = get_input("Enter target URL")
    if url is None:
        return
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    lines = [f"WAF DETECTION: {url}", "=" * 50]

    section("Normal Request")
    r = http_get(url, timeout=10)
    if not r:
        error("Could not reach target.")
        return

    headers_lower = {k.lower(): v.lower() for k, v in r.headers.items()}
    cookies_str = " ".join(r.cookies.keys()).lower()
    body_lower  = r.text[:5000].lower()

    detected = []
    for waf, sigs in WAF_SIGNATURES.items():
        for sig in sigs:
            sig_l = sig.lower()
            if (sig_l in headers_lower or sig_l in cookies_str or
                    any(sig_l in v for v in headers_lower.values())):
                detected.append(waf)
                break

    section("Sending suspicious payload to trigger WAF...")
    evil_url = url + "/?id=1%20AND%201=1--&<script>alert(1)</script>"
    r2 = http_get(evil_url, timeout=10)

    if r2:
        if r2.status_code in (403, 406, 429, 503):
            info(f"Suspicious request returned HTTP {r2.status_code} - WAF likely active")
            lines.append(f"Blocked status: {r2.status_code}")
        for waf, sigs in WAF_SIGNATURES.items():
            body2 = r2.text[:5000].lower()
            for sig in sigs:
                if sig.lower() in body2 and waf not in detected:
                    detected.append(waf)

    if detected:
        for waf in detected:
            print(f"  {RED}[WAF DETECTED]{RESET} {waf}")
            lines.append(f"WAF: {waf}")
    else:
        success("No WAF signatures detected. Target may be unprotected or using a custom WAF.")
        lines.append("Result: No WAF detected")

    info(f"Response status: {r.status_code}")
    info(f"Server header: {r.headers.get('Server', 'N/A')}")

    prompt_save("\n".join(lines), "waf_detect")
