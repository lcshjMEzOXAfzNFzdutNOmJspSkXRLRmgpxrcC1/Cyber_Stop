name = "Dox Tool (Combined OSINT)"

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, validate_ip, validate_email, validate_domain, prompt_save, http_get

    banner("DOX TOOL - COMBINED OSINT", RED)

    print(f"""
  {RED}{'='*58}{RESET}
  {YELLOW}  ETHICS WARNING & LEGAL NOTICE{RESET}
  {RED}{'='*58}{RESET}

  This module performs automated OSINT against a target.
  Use ONLY on targets you have EXPLICIT written permission
  to investigate. Unauthorized use may violate:

  - Computer Fraud and Abuse Act (CFAA)
  - GDPR / Data Protection Laws
  - Local privacy and stalking laws

  {RED}Unauthorized use is ILLEGAL and UNETHICAL.{RESET}
  {RED}{'='*58}{RESET}
""")

    confirm = input("  I confirm I have authorization to investigate this target [yes/NO]: ")
    if confirm.lower() != "yes":
        warn("Operation cancelled.")
        return

    print(f"\n  Target types: {CYAN}[1]{RESET} Username  {CYAN}[2]{RESET} Email  {CYAN}[3]{RESET} Domain  {CYAN}[4]{RESET} IP  {CYAN}[5]{RESET} Phone")
    t_type = get_input("Select target type")
    target = get_input("Enter target value")
    if not target or not t_type:
        return

    report = [
        "=" * 60,
        "          CYBERSTOP DOX REPORT",
        f"  Target: {target}",
        f"  Type:   {t_type}",
        "=" * 60,
        "",
    ]

    import datetime
    report.append(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    if t_type == "1":
        section("Running Username Search...")
        _run_username(target, report)

    elif t_type == "2":
        section("Running Email Breach Check...")
        _run_email(target, report)

    elif t_type == "3":
        section("Running Domain Intelligence...")
        _run_domain(target, report)

    elif t_type == "4":
        section("Running IP Intelligence...")
        _run_ip(target, report)

    elif t_type == "5":
        section("Running Phone Lookup...")
        _run_phone(target, report)

    print(f"\n  {GREEN}Report compiled.{RESET}")
    output = "\n".join(report)
    prompt_save(output, f"dox_{target.replace('.','_')}")


def _run_username(username, report):
    from utils.colors import GREEN, RED, RESET
    from utils.helpers import http_get
    import threading

    PLATFORMS = [
        ("GitHub",   "https://github.com/{}"),
        ("Twitter",  "https://twitter.com/{}"),
        ("Reddit",   "https://reddit.com/user/{}"),
        ("Instagram","https://instagram.com/{}"),
        ("TikTok",   "https://tiktok.com/@{}"),
        ("LinkedIn", "https://linkedin.com/in/{}"),
        ("GitLab",   "https://gitlab.com/{}"),
        ("Medium",   "https://medium.com/@{}"),
        ("Twitch",   "https://twitch.tv/{}"),
    ]
    report.append("=== USERNAME SEARCH ===")
    found = []
    lock = threading.Lock()

    def check(platform, url_template):
        import requests
        try:
            url = url_template.format(username)
            r = requests.get(url, timeout=6, headers={"User-Agent": "Mozilla/5.0"})
            if r.status_code == 200:
                with lock:
                    found.append(f"[FOUND] {platform}: {url}")
                    print(f"  {GREEN}[FOUND]{RESET} {platform}: {url}")
        except Exception:
            pass

    threads = [threading.Thread(target=check, args=(p, u), daemon=True) for p, u in PLATFORMS]
    for t in threads: t.start()
    for t in threads: t.join()

    report.extend(found if found else ["No public profiles found."])


def _run_email(email, report):
    from utils.helpers import http_get
    from utils.colors import GREEN, RED, RESET

    report.append("=== EMAIL BREACH CHECK ===")
    try:
        import requests
        r = requests.get(
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}",
            timeout=10, headers={"User-Agent": "CyberStop/1.0"}
        )
        if r.status_code == 404:
            report.append("Status: Clean - no breaches found")
            print(f"  {GREEN}[CLEAN]{RESET} No breaches found")
        elif r.status_code == 200:
            breaches = r.json()
            report.append(f"Status: PWNED - Found in {len(breaches)} breach(es)")
            for b in breaches:
                report.append(f"  Breach: {b.get('Name')} ({b.get('BreachDate')})")
                print(f"  {RED}[BREACH]{RESET} {b.get('Name')} ({b.get('BreachDate')})")
        else:
            report.append(f"Status: Error {r.status_code} (API key may be required)")
    except Exception as e:
        report.append(f"Error: {e}")


def _run_domain(domain, report):
    from utils.helpers import http_get
    from utils.colors import GREEN, YELLOW, RESET

    report.append("=== DOMAIN INTELLIGENCE ===")

    r = http_get(f"http://ip-api.com/json/{domain}")
    if r:
        try:
            d = r.json()
            if d.get("status") == "success":
                for k in ["query", "country", "city", "isp", "org", "as"]:
                    report.append(f"{k.title()}: {d.get(k, 'N/A')}")
        except Exception:
            pass

    try:
        import dns.resolver
        res = dns.resolver.Resolver()
        res.timeout = 5
        for rtype in ["A", "MX", "NS", "TXT"]:
            try:
                answers = res.resolve(domain, rtype)
                for a in answers:
                    report.append(f"{rtype}: {a.to_text()}")
                    print(f"  {GREEN}[{rtype}]{RESET} {a.to_text()}")
            except Exception:
                pass
    except ImportError:
        report.append("dnspython not installed - DNS skipped")

    r2 = http_get(f"https://crt.sh/?q=%.{domain}&output=json", timeout=15)
    if r2:
        try:
            subs = set()
            for entry in r2.json():
                for sub in entry.get("name_value", "").split("\n"):
                    sub = sub.strip().lstrip("*.")
                    if sub.endswith(domain) and sub != domain:
                        subs.add(sub)
            report.append(f"Subdomains (crt.sh): {', '.join(sorted(subs)[:20])}")
        except Exception:
            pass


def _run_ip(ip, report):
    from utils.helpers import http_get
    from utils.colors import GREEN, RESET

    report.append("=== IP INTELLIGENCE ===")
    r = http_get(f"http://ip-api.com/json/{ip}?fields=status,country,city,isp,org,as,query")
    if r:
        try:
            d = r.json()
            for k in ["query", "country", "city", "isp", "org", "as"]:
                val = d.get(k, "N/A")
                report.append(f"{k.title()}: {val}")
                print(f"  {GREEN}[+]{RESET} {k.title()}: {val}")
        except Exception:
            pass

    r2 = http_get(f"https://api.bgpview.io/ip/{ip}", timeout=10)
    if r2 and r2.status_code == 200:
        try:
            for p in r2.json().get("data", {}).get("prefixes", [])[:3]:
                report.append(f"Prefix: {p.get('prefix')} AS{p.get('asn',{}).get('asn')}")
        except Exception:
            pass


def _run_phone(phone, report):
    from utils.colors import GREEN, RESET

    report.append("=== PHONE LOOKUP ===")
    report.append(f"Number: {phone}")

    COUNTRY_CODES = {
        "1": "USA/Canada", "44": "UK", "33": "France", "49": "Germany",
        "91": "India", "86": "China", "7": "Russia", "55": "Brazil",
        "81": "Japan", "82": "South Korea",
    }

    digits = phone.lstrip("+")
    for code in sorted(COUNTRY_CODES.keys(), key=len, reverse=True):
        if digits.startswith(code):
            country = COUNTRY_CODES[code]
            report.append(f"Country: {country} (+{code})")
            print(f"  {GREEN}[+]{RESET} Country: {country} (+{code})")
            break
