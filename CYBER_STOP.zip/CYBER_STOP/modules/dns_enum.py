name = "DNS Enumeration"

RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME", "CAA"]

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RED, RESET
    from utils.helpers import get_input, validate_domain, prompt_save

    banner("DNS ENUMERATION", CYAN)
    print(f"  {CYAN}Query A, AAAA, MX, NS, TXT, SPF, DKIM, DMARC, CNAME records.{RESET}\n")

    domain = get_input("Enter domain (e.g. example.com)")
    if domain is None:
        return
    domain = domain.strip().lower().replace("https://", "").replace("http://", "").split("/")[0]

    lines = [f"DNS ENUMERATION: {domain}", "=" * 50]

    try:
        import dns.resolver
        resolver = dns.resolver.Resolver()
        resolver.timeout = 5
        resolver.lifetime = 5

        for rtype in RECORD_TYPES:
            section(f"{rtype} Records")
            try:
                answers = resolver.resolve(domain, rtype)
                for rdata in answers:
                    val = rdata.to_text()
                    print(f"  {GREEN}{rtype:<8}{RESET} {val}")
                    lines.append(f"{rtype}: {val}")
            except Exception:
                print(f"  {YELLOW}{rtype:<8}{RESET} (none / no record)")

        for prefix, label in [("_dmarc", "DMARC"), ("default._domainkey", "DKIM(default)")]:
            subdomain = f"{prefix}.{domain}"
            section(f"{label} Record")
            try:
                answers = resolver.resolve(subdomain, "TXT")
                for rdata in answers:
                    val = rdata.to_text()
                    print(f"  {GREEN}{label:<12}{RESET} {val}")
                    lines.append(f"{label}: {val}")
            except Exception:
                print(f"  {YELLOW}{label:<12}{RESET} (not found)")

    except ImportError:
        warn("dnspython not installed. Install with: pip install dnspython")
        warn("Falling back to system nslookup...")
        _fallback_dns(domain, lines)

    prompt_save("\n".join(lines), "dns_enum")


def _fallback_dns(domain, lines):
    import subprocess
    from utils.colors import success, error, GREEN, RESET
    for rtype in ["A", "MX", "NS", "TXT"]:
        try:
            result = subprocess.run(
                ["nslookup", "-type=" + rtype, domain],
                capture_output=True, text=True, timeout=8
            )
            output = result.stdout
            print(f"\n  {GREEN}--- {rtype} ---{RESET}")
            for line in output.splitlines()[3:]:
                if line.strip():
                    print(f"  {line}")
            lines.append(f"\n{rtype}:\n{output}")
        except Exception as e:
            from utils.colors import error as err
            err(f"{rtype} lookup failed: {e}")
