name = "Subdomain Enumeration"

COMMON_SUBDOMAINS = [
    "www", "mail", "ftp", "smtp", "pop", "imap", "webmail", "remote",
    "blog", "shop", "store", "dev", "staging", "test", "api", "admin",
    "portal", "vpn", "ns1", "ns2", "dns", "mx", "media", "static",
    "cdn", "img", "images", "assets", "docs", "help", "support", "forum",
    "chat", "m", "mobile", "app", "apps", "git", "svn", "jenkins",
    "jira", "confluence", "wiki", "db", "database", "mysql", "sql",
    "mongodb", "redis", "elastic", "kibana", "grafana", "prometheus",
    "backup", "files", "download", "upload", "secure", "auth", "login",
    "register", "dashboard", "panel", "cpanel", "whm", "phpmyadmin",
    "beta", "alpha", "stage", "prod", "production", "uat", "qa",
    "internal", "intranet", "extranet", "corp", "office",
]

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, validate_domain, prompt_save, progress_bar

    banner("SUBDOMAIN ENUMERATION", CYAN)
    print(f"  {CYAN}Discover subdomains via crt.sh + common wordlist brute-force.{RESET}\n")

    domain = get_input("Enter domain (e.g. example.com)")
    if domain is None:
        return
    domain = domain.strip().lower().replace("https://", "").replace("http://", "").split("/")[0]

    found = set()
    lines = [f"SUBDOMAIN ENUMERATION: {domain}", "=" * 50]

    section("Querying crt.sh certificate transparency logs...")
    try:
        import requests
        r = requests.get(
            f"https://crt.sh/?q=%.{domain}&output=json",
            timeout=15, headers={"User-Agent": "CyberStop/1.0"}
        )
        if r.status_code == 200:
            entries = r.json()
            for entry in entries:
                name_value = entry.get("name_value", "")
                for sub in name_value.split("\n"):
                    sub = sub.strip().lstrip("*.")
                    if sub.endswith(domain) and sub != domain:
                        found.add(sub)
            success(f"crt.sh found {len(found)} subdomains.")
        else:
            warn(f"crt.sh returned status {r.status_code}")
    except Exception as e:
        warn(f"crt.sh query failed: {e}")

    section(f"Brute-forcing {len(COMMON_SUBDOMAINS)} common subdomains...")
    try:
        import dns.resolver
        resolver = dns.resolver.Resolver()
        resolver.timeout = 2
        resolver.lifetime = 2

        import threading
        lock = threading.Lock()
        brute_found = []

        def check_sub(sub):
            full = f"{sub}.{domain}"
            try:
                resolver.resolve(full, "A")
                with lock:
                    brute_found.append(full)
                    print(f"  {GREEN}[FOUND]{RESET} {full}")
            except Exception:
                pass

        threads = [threading.Thread(target=check_sub, args=(s,), daemon=True) for s in COMMON_SUBDOMAINS]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        found.update(brute_found)
        success(f"Brute-force found {len(brute_found)} additional subdomains.")
    except ImportError:
        warn("dnspython not installed (pip install dnspython). Skipping brute-force.")

    if found:
        print(f"\n  {GREEN}Total unique subdomains found: {len(found)}{RESET}")
        for sub in sorted(found):
            print(f"    {sub}")
        lines.extend(sorted(found))
    else:
        warn("No subdomains found.")

    prompt_save("\n".join(lines), "subdomain_enum")
