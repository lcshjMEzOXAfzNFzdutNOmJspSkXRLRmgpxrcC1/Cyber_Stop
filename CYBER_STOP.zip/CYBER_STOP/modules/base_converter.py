name = "Base Converter"

def run():
    from utils.colors import banner, section, success, error, info, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("BASE CONVERTER", CYAN)
    print(f"  {CYAN}Convert between binary, decimal, hexadecimal, and octal.{RESET}\n")

    bases = {"1": ("Binary", 2), "2": ("Decimal", 10), "3": ("Hex", 16), "4": ("Octal", 8)}
    for k, (n, _) in bases.items():
        print(f"    [{k}] {n}")

    from_choice = get_input("Convert FROM")
    if from_choice not in bases:
        error("Invalid choice.")
        return

    value = get_input("Enter value")
    if value is None:
        return

    from_name, from_base = bases[from_choice]

    try:
        decimal = int(value.strip(), from_base)
    except ValueError:
        error(f"'{value}' is not a valid {from_name} number.")
        return

    section("Conversions")
    results = []
    for k, (name, base) in bases.items():
        if base == 2:
            converted = bin(decimal)[2:]
        elif base == 8:
            converted = oct(decimal)[2:]
        elif base == 10:
            converted = str(decimal)
        elif base == 16:
            converted = hex(decimal)[2:].upper()
        print(f"  {GREEN}{name:<10}{RESET}: {converted}")
        results.append(f"{name}: {converted}")

    prompt_save("\n".join(results), "base_convert")
