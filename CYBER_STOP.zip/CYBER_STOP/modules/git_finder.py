name = "Git Repo Finder"

PATHS_TO_CHECK = [
    "/.git/config",
    "/.git/HEAD",
    "/.git/COMMIT_EDITMSG",
    "/.git/index",
    "/.git/logs/HEAD",
    "/.gitignore",
    "/.env",
    "/.env.local",
    "/.env.backup",
    "/config.php",
    "/config.yml",
    "/config.yaml",
    "/credentials.json",
    "/secrets.json",
    "/wp-config.php",
    "/database.yml",
    "/settings.py",
    "/local_settings.py",
    "/.DS_Store",
    "/robots.txt",
    "/sitemap.xml",
    "/crossdomain.xml",
    "/phpinfo.php",
    "/server-status",
    "/elmah.axd",
    "/trace.axd",
    "/api/swagger.json",
    "/api/openapi.json",
    "/swagger.json",
    "/openapi.yaml",
    "/.svn/entries",
    "/CVS/Entries",
    "/Dockerfile",
    "/docker-compose.yml",
]

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, prompt_save, http_get
    import threading

    banner("GIT / SECRETS FINDER", CYAN)
    print(f"  {CYAN}Check for exposed .git, .env, configs, and sensitive files.{RESET}\n")

    url = get_input("Enter target URL (e.g. https://example.com)")
    if url is None:
        return
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    base = url.rstrip("/")

    found = []
    lock = threading.Lock()
    lines = [f"GIT/SECRETS FINDER: {url}", "=" * 50]

    section(f"Checking {len(PATHS_TO_CHECK)} sensitive paths...")

    def check(path):
        r = http_get(base + path, timeout=6)
        if r and r.status_code in (200, 403):
            size = len(r.content)
            with lock:
                found.append((path, r.status_code, size))
                color = RED if r.status_code == 200 else YELLOW
                print(f"  {color}[{r.status_code}]{RESET} {path} ({size} bytes)")
                lines.append(f"[{r.status_code}] {path} ({size} bytes)")

    threads = [threading.Thread(target=check, args=(p,), daemon=True) for p in PATHS_TO_CHECK]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    if not found:
        success("No exposed sensitive files found.")
        lines.append("Result: Clean - no exposures found")
    else:
        error(f"Found {len(found)} potentially exposed path(s)!")
        critical = [f for f in found if f[1] == 200]
        if critical:
            error(f"  {len(critical)} paths returned HTTP 200 (fully accessible!)")

    prompt_save("\n".join(lines), "git_finder")
