name = "Hash Generator"

import hashlib

ALGORITHMS = ["md5", "sha1", "sha224", "sha256", "sha384", "sha512", "sha3_256", "sha3_512"]

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("HASH GENERATOR", CYAN)
    print(f"  {CYAN}Compute MD5, SHA1, SHA256, SHA512, SHA3 and more.{RESET}\n")

    text = get_input("Enter text to hash")
    if text is None:
        return

    section("Computed Hashes")
    lines = [f"INPUT: {text}", "=" * 60]
    for algo in ALGORITHMS:
        try:
            h = hashlib.new(algo, text.encode("utf-8")).hexdigest()
            print(f"  {GREEN}{algo.upper():<12}{RESET}: {h}")
            lines.append(f"{algo.upper()}: {h}")
        except Exception as e:
            warn(f"{algo}: {e}")

    try:
        import bcrypt
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(text.encode("utf-8"), salt)
        bh = hashed.decode()
        print(f"  {GREEN}{'BCRYPT':<12}{RESET}: {bh}")
        lines.append(f"BCRYPT: {bh}")
    except ImportError:
        info("bcrypt not installed (pip install bcrypt) - skipping")

    prompt_save("\n".join(lines), "hash_gen")
