name = "File Hasher"

import hashlib
import os

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("FILE HASHER", CYAN)
    print(f"  {CYAN}Compute MD5, SHA1, SHA256, SHA512 hashes of any file.{RESET}\n")

    filepath = get_input("Enter file path")
    if filepath is None:
        return

    filepath = filepath.strip().strip('"').strip("'")
    if not os.path.isfile(filepath):
        error(f"File not found: {filepath}")
        return

    size = os.path.getsize(filepath)
    section(f"Hashing: {filepath}")
    info(f"File size: {size:,} bytes ({size/1024:.1f} KB)")

    algos = [("MD5", hashlib.md5()), ("SHA1", hashlib.sha1()),
             ("SHA256", hashlib.sha256()), ("SHA512", hashlib.sha512())]

    try:
        with open(filepath, "rb") as f:
            while chunk := f.read(65536):
                for _, h in algos:
                    h.update(chunk)
    except Exception as e:
        error(f"Could not read file: {e}")
        return

    lines = [f"FILE HASH: {filepath}", f"Size: {size} bytes", "=" * 60]
    for name, h in algos:
        digest = h.hexdigest()
        print(f"  {GREEN}{name:<8}{RESET}: {digest}")
        lines.append(f"{name}: {digest}")

    known = get_input("Enter known hash to verify (optional)", required=False)
    if known:
        known = known.strip().lower()
        match = any(h.hexdigest() == known for _, h in algos)
        if match:
            success("HASH MATCH! File integrity verified.")
            lines.append(f"Verification: MATCH ({known})")
        else:
            error("HASH MISMATCH! File may be corrupted or tampered.")
            lines.append(f"Verification: MISMATCH")

    prompt_save("\n".join(lines), "file_hashes")
