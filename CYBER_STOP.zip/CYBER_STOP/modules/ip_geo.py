name = "IP Geolocation"

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, RESET, GREEN, YELLOW
    from utils.helpers import get_input, validate_ip, prompt_save, http_get

    banner("IP GEOLOCATION", CYAN)
    print(f"  {CYAN}Query IP-API.com for country, city, ISP, ASN, and coordinates.{RESET}\n")

    ip = get_input("Enter IP address (or 'me' for your own)")
    if ip is None:
        return

    if ip.lower() == "me":
        ip = ""

    section("Querying ip-api.com...")
    url = f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query"
    r = http_get(url)

    if not r:
        error("Network request failed.")
        return

    try:
        data = r.json()
    except Exception:
        error("Failed to parse response.")
        return

    if data.get("status") != "success":
        error(f"Lookup failed: {data.get('message', 'Unknown error')}")
        return

    lines = []
    fields = [
        ("IP Address",  "query"),
        ("Country",     "country"),
        ("Country Code","countryCode"),
        ("Region",      "regionName"),
        ("City",        "city"),
        ("ZIP Code",    "zip"),
        ("Latitude",    "lat"),
        ("Longitude",   "lon"),
        ("Timezone",    "timezone"),
        ("ISP",         "isp"),
        ("Organization","org"),
        ("ASN",         "as"),
    ]
    for label, key in fields:
        val = data.get(key, "N/A")
        line = f"  {label:<16}: {val}"
        print(f"  {GREEN}{label:<16}{RESET}: {val}")
        lines.append(line)

    output = "\n".join(lines)
    prompt_save(output, "ip_geolocation")
