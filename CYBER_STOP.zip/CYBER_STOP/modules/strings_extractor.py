name = "Strings Extractor"

import re
import os

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("STRINGS EXTRACTOR", CYAN)
    print(f"  {CYAN}Extract ASCII/Unicode printable strings from binary files.{RESET}\n")

    filepath = get_input("Enter file path")
    if filepath is None:
        return
    filepath = filepath.strip().strip('"').strip("'")
    if not os.path.isfile(filepath):
        error(f"File not found: {filepath}")
        return

    min_len_str = get_input("Minimum string length (default 4)", required=False) or "4"
    try:
        min_len = int(min_len_str)
    except ValueError:
        min_len = 4

    section(f"Extracting strings (min length {min_len})...")
    lines = [f"STRINGS: {filepath}", f"Min length: {min_len}", "=" * 60]

    try:
        with open(filepath, "rb") as f:
            content = f.read()
    except Exception as e:
        error(f"Cannot read file: {e}")
        return

    pattern = rb"[\x20-\x7e]{" + str(min_len).encode() + rb",}"
    ascii_strings = re.findall(pattern, content)

    unicode_strings = []
    pattern_u = rb"(?:[\x20-\x7e]\x00){" + str(min_len).encode() + rb",}"
    for m in re.finditer(pattern_u, content):
        try:
            s = m.group().decode("utf-16-le")
            unicode_strings.append(s)
        except Exception:
            pass

    interesting = []
    keywords = ["http", "https", "ftp", "://", "password", "passwd", "secret",
                "key", "api", "token", "user", "admin", "root", "cmd", "eval",
                "exec", "shell", "powershell", "bash", ".exe", ".dll", ".so"]

    section(f"Found {len(ascii_strings)} ASCII + {len(unicode_strings)} Unicode strings")
    count = 0
    for s in ascii_strings:
        decoded = s.decode("ascii", errors="replace")
        is_interesting = any(kw in decoded.lower() for kw in keywords)
        if is_interesting:
            interesting.append(decoded)
            print(f"  {YELLOW}[!]{RESET} {decoded[:120]}")
        elif count < 50:
            print(f"  {GREEN}[+]{RESET} {decoded[:120]}")
        count += 1
        lines.append(decoded[:200])

    if interesting:
        section(f"Interesting strings ({len(interesting)} found)")
        for s in interesting:
            print(f"  {YELLOW}{s[:120]}{RESET}")

    info(f"Total: {len(ascii_strings)} ASCII, {len(unicode_strings)} Unicode strings")
    prompt_save("\n".join(lines), "strings_extract")
