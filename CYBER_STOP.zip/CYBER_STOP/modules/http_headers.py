name = "HTTP Headers"

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
    "X-XSS-Protection",
    "Access-Control-Allow-Origin",
    "Cache-Control",
]

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, prompt_save, http_get

    banner("HTTP HEADERS ANALYZER", CYAN)
    print(f"  {CYAN}Fetch and analyze HTTP response headers for security findings.{RESET}\n")

    url = get_input("Enter URL (e.g. https://example.com)")
    if url is None:
        return
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    section(f"Fetching headers from: {url}")
    r = http_get(url, timeout=10)
    if not r:
        error("Failed to connect to the target.")
        return

    lines = [f"HTTP HEADERS: {url}", f"Status: {r.status_code}", "=" * 50]

    print(f"\n  {CYAN}Status Code:{RESET} {r.status_code} {r.reason}")
    print(f"  {CYAN}Final URL:{RESET}   {r.url}\n")

    section("All Headers")
    for key, val in r.headers.items():
        print(f"  {GREEN}{key:<40}{RESET} {val}")
        lines.append(f"{key}: {val}")

    section("Security Header Analysis")
    for h in SECURITY_HEADERS:
        if h in r.headers:
            print(f"  {GREEN}[PRESENT]{RESET} {h}: {r.headers[h]}")
        else:
            print(f"  {RED}[MISSING]{RESET} {h}")
            lines.append(f"MISSING: {h}")

    prompt_save("\n".join(lines), "http_headers")
