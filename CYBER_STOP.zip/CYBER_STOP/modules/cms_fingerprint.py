name = "CMS Fingerprinting"

CMS_SIGNATURES = {
    "WordPress": {
        "paths":    ["/wp-login.php", "/wp-admin/", "/wp-content/", "/xmlrpc.php"],
        "headers":  [],
        "body":     ["wp-content", "WordPress", "wp-json"],
    },
    "Joomla": {
        "paths":    ["/administrator/", "/components/", "/modules/"],
        "headers":  [],
        "body":     ["Joomla", "/media/jui/", "mosConfig"],
    },
    "Drupal": {
        "paths":    ["/sites/default/", "/modules/", "/themes/"],
        "headers":  ["X-Generator: Drupal"],
        "body":     ["Drupal", "drupal.js", "/sites/all/"],
    },
    "Magento": {
        "paths":    ["/skin/frontend/", "/js/mage/"],
        "headers":  [],
        "body":     ["Magento", "skin/frontend"],
    },
    "Shopify": {
        "paths":    [],
        "headers":  ["X-Shopify-Stage"],
        "body":     ["Shopify.theme", "cdn.shopify.com"],
    },
    "Wix": {
        "paths":    [],
        "headers":  [],
        "body":     ["wix.com", "X-Wix-Published-Version"],
    },
    "Squarespace": {
        "paths":    [],
        "headers":  [],
        "body":     ["squarespace.com", "SQUARESPACE_LOGIN"],
    },
    "Ghost": {
        "paths":    ["/ghost/api/", "/ghost/"],
        "headers":  [],
        "body":     ["ghost.io", "Ghost v"],
    },
}

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RED, RESET
    from utils.helpers import get_input, prompt_save, http_get

    banner("CMS FINGERPRINTING", CYAN)
    print(f"  {CYAN}Detect WordPress, Joomla, Drupal, Shopify, and more.{RESET}\n")

    url = get_input("Enter target URL (e.g. https://example.com)")
    if url is None:
        return
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    base = url.rstrip("/")
    lines = [f"CMS FINGERPRINT: {url}", "=" * 50]
    detected = []

    section("Fetching main page...")
    r = http_get(base)
    if not r:
        error("Could not reach target.")
        return

    body = r.text.lower()
    headers_str = str(r.headers).lower()

    for cms, sigs in CMS_SIGNATURES.items():
        hits = 0
        for kw in sigs["body"]:
            if kw.lower() in body:
                hits += 1
        for hdr in sigs["headers"]:
            if hdr.lower().split(":")[0] in headers_str:
                hits += 1
        if hits:
            detected.append((cms, hits, "body/header"))

    section("Checking known CMS paths...")
    for cms, sigs in CMS_SIGNATURES.items():
        for path in sigs["paths"]:
            r2 = http_get(base + path, timeout=5)
            if r2 and r2.status_code in (200, 301, 302, 403):
                existing = [d[0] for d in detected]
                if cms not in existing:
                    detected.append((cms, 1, "path"))
                print(f"  {GREEN}[{r2.status_code}]{RESET} {base + path} => {cms}")
                lines.append(f"Path found [{r2.status_code}]: {base + path} => {cms}")

    if detected:
        detected.sort(key=lambda x: -x[1])
        top = detected[0]
        print(f"\n  {GREEN}[DETECTED]{RESET} Most likely CMS: {top[0]} (confidence hits: {top[1]})")
        for cms, hits, source in detected:
            print(f"  {YELLOW}Candidate:{RESET} {cms} (hits: {hits}, via: {source})")
            lines.append(f"Candidate: {cms} (hits: {hits})")
    else:
        info("No CMS detected or it's a custom/unknown platform.")
        lines.append("Result: No CMS detected")

    prompt_save("\n".join(lines), "cms_fingerprint")
