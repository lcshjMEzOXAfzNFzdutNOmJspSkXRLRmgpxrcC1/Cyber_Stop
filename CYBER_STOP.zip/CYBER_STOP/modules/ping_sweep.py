name = "Ping Sweep"

import subprocess
import platform
import threading

def ping_host(host):
    param = "-n" if platform.system().lower() == "windows" else "-c"
    try:
        result = subprocess.run(
            ["ping", param, "1", "-W", "1", host],
            capture_output=True, text=True, timeout=3
        )
        return result.returncode == 0
    except Exception:
        return False

def run():
    import ipaddress
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("PING SWEEP", CYAN)
    print(f"  {CYAN}Discover live hosts in a subnet via ICMP echo requests.{RESET}\n")

    subnet = get_input("Enter subnet (e.g. 192.168.1.0/24) or IP range (192.168.1.1-50)")
    if subnet is None:
        return

    hosts = []
    try:
        if "/" in subnet:
            network = ipaddress.IPv4Network(subnet, strict=False)
            hosts = [str(h) for h in network.hosts()]
        elif "-" in subnet:
            base, end_str = subnet.rsplit(".", 1)[0], subnet.rsplit(".", 1)[1]
            if "-" in end_str:
                parts = end_str.split("-")
                start, end = int(parts[0]), int(parts[1])
                hosts = [f"{subnet.rsplit('.', 1)[0]}.{i}" for i in range(start, end+1)]
            else:
                hosts = [subnet]
        else:
            hosts = [subnet]
    except Exception as e:
        error(f"Invalid input: {e}")
        return

    if len(hosts) > 256:
        warn(f"Scanning {len(hosts)} hosts. This may take a while...")
    else:
        section(f"Sweeping {len(hosts)} hosts...")

    alive = []
    lock = threading.Lock()

    def check(host):
        if ping_host(host):
            with lock:
                alive.append(host)
                print(f"  {GREEN}[UP]{RESET}   {host}")

    threads = [threading.Thread(target=check, args=(h,), daemon=True) for h in hosts]
    BATCH = 50
    for i in range(0, len(threads), BATCH):
        batch = threads[i:i+BATCH]
        for t in batch:
            t.start()
        for t in batch:
            t.join()

    alive.sort(key=lambda ip: tuple(int(x) for x in ip.split(".")))
    print(f"\n  {GREEN}Alive hosts: {len(alive)}{RESET} of {len(hosts)} scanned")

    lines = [f"PING SWEEP: {subnet}", "=" * 50] + alive
    prompt_save("\n".join(lines), "ping_sweep")
