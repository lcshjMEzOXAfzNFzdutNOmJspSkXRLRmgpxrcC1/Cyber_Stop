name = "Phone Number Lookup"

COUNTRY_CODES = {
    "1":  "USA/Canada",   "7":  "Russia",       "20": "Egypt",
    "27": "South Africa", "30": "Greece",        "31": "Netherlands",
    "32": "Belgium",      "33": "France",        "34": "Spain",
    "36": "Hungary",      "39": "Italy",         "40": "Romania",
    "41": "Switzerland",  "43": "Austria",       "44": "UK",
    "45": "Denmark",      "46": "Sweden",        "47": "Norway",
    "48": "Poland",       "49": "Germany",       "51": "Peru",
    "52": "Mexico",       "54": "Argentina",     "55": "Brazil",
    "56": "Chile",        "57": "Colombia",      "58": "Venezuela",
    "60": "Malaysia",     "61": "Australia",     "62": "Indonesia",
    "63": "Philippines",  "64": "New Zealand",   "65": "Singapore",
    "66": "Thailand",     "81": "Japan",         "82": "South Korea",
    "84": "Vietnam",      "86": "China",         "90": "Turkey",
    "91": "India",        "92": "Pakistan",      "93": "Afghanistan",
    "94": "Sri Lanka",    "95": "Myanmar",       "98": "Iran",
}

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save, http_get

    banner("PHONE NUMBER LOOKUP", CYAN)
    print(f"  {CYAN}Carrier detection, region, VoIP detection via public APIs.{RESET}\n")

    phone = get_input("Enter phone number (with country code, e.g. +14155552671)")
    if phone is None:
        return

    phone_clean = "".join(c for c in phone if c.isdigit() or c == "+")
    if not phone_clean.startswith("+"):
        phone_clean = "+" + phone_clean

    lines = [f"PHONE LOOKUP: {phone_clean}", "=" * 50]

    section("Country Code Detection")
    digits = phone_clean.lstrip("+")
    detected_country = "Unknown"
    for code in sorted(COUNTRY_CODES.keys(), key=len, reverse=True):
        if digits.startswith(code):
            detected_country = COUNTRY_CODES[code]
            print(f"  {GREEN}Country Code:{RESET} +{code} ({detected_country})")
            lines.append(f"Country Code: +{code} ({detected_country})")
            break

    section("Querying numverify (free tier - basic info)...")
    try:
        import requests
        r = requests.get(
            f"https://api.apilayer.com/number_verification/validate?number={phone_clean}",
            timeout=8,
            headers={"apikey": "demo"}
        )
        if r.status_code == 200:
            data = r.json()
            for key in ["valid", "country_name", "location", "carrier", "line_type"]:
                val = data.get(key, "N/A")
                print(f"  {GREEN}{key.replace('_',' ').title():<16}{RESET}: {val}")
                lines.append(f"{key}: {val}")
    except Exception:
        pass

    section("Querying phone-api.com (free lookup)...")
    try:
        import requests
        r2 = requests.get(
            f"https://api.phone-api.com/v1/{phone_clean}",
            timeout=8
        )
        if r2.status_code == 200:
            data2 = r2.json()
            for key, val in data2.items():
                print(f"  {GREEN}{key:<16}{RESET}: {val}")
    except Exception:
        pass

    info(f"Number format: {phone_clean}")
    info(f"Detected region: {detected_country}")

    lines.append(f"Detected Region: {detected_country}")
    prompt_save("\n".join(lines), "phone_lookup")
