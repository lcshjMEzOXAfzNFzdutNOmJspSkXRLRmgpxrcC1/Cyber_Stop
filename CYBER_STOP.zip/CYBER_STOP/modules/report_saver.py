name = "Report Saver"

def run():
    import os
    from pathlib import Path
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, ensure_dir

    banner("REPORT SAVER", CYAN)
    print(f"  {CYAN}View and manage saved reports in the reports/ directory.{RESET}\n")

    reports_dir = ensure_dir()
    files = sorted(reports_dir.glob("*"), key=os.path.getmtime, reverse=True)

    if not files:
        info("No reports saved yet. Run modules and choose to save output.")
        return

    section("Saved Reports")
    for i, f in enumerate(files):
        size = f.stat().st_size
        mtime = f.stat().st_mtime
        import datetime
        ts = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
        print(f"  {GREEN}[{i+1}]{RESET} {f.name:<40} {ts}  {size:,} bytes")

    choice = get_input("Enter report number to view (or Enter to exit)", required=False)
    if not choice:
        return

    try:
        idx = int(choice) - 1
        filepath = files[idx]
    except (ValueError, IndexError):
        error("Invalid selection.")
        return

    section(f"Contents of: {filepath.name}")
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    lines = content.splitlines()
    if len(lines) > 60:
        warn(f"File has {len(lines)} lines. Showing first 60.")
        lines = lines[:60]

    for line in lines:
        print(f"  {line}")

    action = input("\n  [D]elete this report / [Q]uit: ").strip().upper()
    if action == "D":
        os.remove(filepath)
        success(f"Deleted: {filepath.name}")
