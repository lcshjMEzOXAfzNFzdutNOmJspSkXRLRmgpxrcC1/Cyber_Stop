name = "Encoding Toolkit"

import base64
import binascii
import urllib.parse
import codecs

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("ENCODING TOOLKIT", CYAN)
    print(f"  {CYAN}Encode/decode: Base64, Base32, Hex, ROT13, URL, Binary.{RESET}\n")

    formats = {
        "1": "Base64",
        "2": "Base32",
        "3": "Hex",
        "4": "ROT13",
        "5": "URL Encode",
        "6": "Binary",
        "7": "HTML Entities",
    }

    for k, v in formats.items():
        print(f"    [{k}] {v}")

    choice = get_input("Select format")
    if choice not in formats:
        error("Invalid choice.")
        return

    fmt = formats[choice]
    op = input("  [E]ncode or [D]ecode? ").strip().upper()
    if op not in ("E", "D"):
        error("Must be E or D.")
        return

    text = get_input("Enter text")
    if text is None:
        return

    result = None
    try:
        if fmt == "Base64":
            if op == "E":
                result = base64.b64encode(text.encode()).decode()
            else:
                result = base64.b64decode(text).decode()

        elif fmt == "Base32":
            if op == "E":
                result = base64.b32encode(text.encode()).decode()
            else:
                result = base64.b32decode(text).decode()

        elif fmt == "Hex":
            if op == "E":
                result = text.encode().hex()
            else:
                result = bytes.fromhex(text).decode()

        elif fmt == "ROT13":
            result = codecs.encode(text, "rot_13")

        elif fmt == "URL Encode":
            if op == "E":
                result = urllib.parse.quote(text)
            else:
                result = urllib.parse.unquote(text)

        elif fmt == "Binary":
            if op == "E":
                result = " ".join(format(ord(c), "08b") for c in text)
            else:
                bits = text.replace(" ", "")
                result = "".join(chr(int(bits[i:i+8], 2)) for i in range(0, len(bits), 8))

        elif fmt == "HTML Entities":
            import html
            if op == "E":
                result = html.escape(text)
            else:
                result = html.unescape(text)

    except Exception as e:
        error(f"Operation failed: {e}")
        return

    section("Result")
    print(f"\n  {GREEN}{result}{RESET}\n")
    prompt_save(result, "encoded")
