name = "XOR Cipher"

def run():
    from utils.colors import banner, section, success, error, info, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("XOR CIPHER", CYAN)
    print(f"  {CYAN}XOR-encrypt or decrypt text using a key. Output in hex.{RESET}\n")

    text = get_input("Enter plaintext (or hex ciphertext to decrypt)")
    if text is None:
        return
    key = get_input("Enter XOR key")
    if key is None:
        return

    op = input("  [E]ncrypt or [D]ecrypt (from hex)? ").strip().upper()

    try:
        if op == "D":
            data = bytes.fromhex(text.replace(" ", ""))
        else:
            data = text.encode("utf-8")

        key_bytes = key.encode("utf-8")
        result_bytes = bytes(b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(data))

        if op == "E":
            result = result_bytes.hex()
            label = "Ciphertext (hex)"
        else:
            result = result_bytes.decode("utf-8", errors="replace")
            label = "Plaintext"

        section("Result")
        print(f"  {GREEN}{label}:{RESET} {result}")
        prompt_save(result, "xor_cipher")
    except Exception as e:
        error(f"XOR operation failed: {e}")
