name = "Wordlist Generator"

LEET_MAP = {"a": "4", "e": "3", "i": "1", "o": "0", "s": "5", "t": "7"}

def leetspeak(word):
    result = []
    for c in word.lower():
        result.append(LEET_MAP.get(c, c))
    return "".join(result)

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("WORDLIST GENERATOR", CYAN)
    print(f"  {CYAN}Create custom wordlists from keywords + mutations.{RESET}\n")

    raw = get_input("Enter keywords (comma-separated, e.g. company,admin,2024)")
    if raw is None:
        return

    keywords = [w.strip() for w in raw.split(",") if w.strip()]
    do_leet    = input("  Include leetspeak variants? [y/N]: ").strip().lower() == "y"
    do_nums    = input("  Append numbers (0-99)?     [y/N]: ").strip().lower() == "y"
    do_caps    = input("  Add CAPS variants?          [y/N]: ").strip().lower() == "y"
    do_symbols = input("  Add !/@/# suffix?           [y/N]: ").strip().lower() == "y"
    do_combos  = input("  Combine pairs of keywords?  [y/N]: ").strip().lower() == "y"
    max_str    = get_input("Max word length (default 20)", required=False) or "20"
    try:
        max_len = int(max_str)
    except ValueError:
        max_len = 20

    section("Generating wordlist...")
    wordset = set(keywords)

    for w in list(wordset):
        wordset.add(w.lower())
        wordset.add(w.upper())
        wordset.add(w.capitalize())

    if do_leet:
        for w in list(wordset):
            wordset.add(leetspeak(w))

    if do_nums:
        for w in list(wordset):
            for n in range(100):
                wordset.add(f"{w}{n}")
                if n < 10:
                    wordset.add(f"{w}0{n}")

    if do_caps:
        for w in list(wordset):
            wordset.add(w.upper())

    if do_symbols:
        for w in list(wordset):
            for sym in ["!", "@", "#", "$", "!"]:
                wordset.add(f"{w}{sym}")

    if do_combos and len(keywords) >= 2:
        for i, w1 in enumerate(keywords):
            for w2 in keywords[i+1:]:
                wordset.add(f"{w1}{w2}")
                wordset.add(f"{w2}{w1}")
                wordset.add(f"{w1}_{w2}")
                wordset.add(f"{w1}-{w2}")

    filtered = [w for w in wordset if len(w) <= max_len and len(w) > 0]
    filtered.sort()

    success(f"Generated {len(filtered)} words.")
    for w in filtered[:30]:
        print(f"  {GREEN}{w}{RESET}")

    if len(filtered) > 30:
        info(f"... and {len(filtered) - 30} more. Save to file to see all.")

    prompt_save("\n".join(filtered), "wordlist")
