name = "Password Strength Checker"

import math
import string

COMMON_PASSWORDS = [
    "password", "123456", "password123", "admin", "letmein", "welcome",
    "monkey", "dragon", "master", "hello", "shadow", "sunshine", "princess",
    "football", "charlie", "donald", "qwerty", "abc123", "iloveyou",
    "123456789", "1234567890", "111111", "654321", "superman", "batman",
    "login", "admin123", "root", "test", "guest", "pass", "1234",
]

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input

    banner("PASSWORD STRENGTH CHECKER", CYAN)
    print(f"  {CYAN}Evaluate entropy, complexity, and common-password detection.{RESET}\n")

    import getpass
    try:
        pwd = getpass.getpass("  Enter password (hidden): ")
    except Exception:
        pwd = get_input("Enter password")

    if pwd is None:
        return

    section("Analysis")
    charset_size = 0
    has_lower = any(c in string.ascii_lowercase for c in pwd)
    has_upper = any(c in string.ascii_uppercase for c in pwd)
    has_digit = any(c in string.digits for c in pwd)
    has_sym   = any(c in string.punctuation for c in pwd)

    if has_lower:  charset_size += 26
    if has_upper:  charset_size += 26
    if has_digit:  charset_size += 10
    if has_sym:    charset_size += 32

    length  = len(pwd)
    entropy = length * math.log2(charset_size) if charset_size else 0

    checks = [
        (has_lower,      "Lowercase letters"),
        (has_upper,      "Uppercase letters"),
        (has_digit,      "Digits"),
        (has_sym,        "Special characters"),
        (length >= 12,   "At least 12 characters"),
        (length >= 16,   "At least 16 characters"),
        (length >= 20,   "At least 20 characters"),
    ]

    score = 0
    for passed, label in checks:
        c = GREEN if passed else RED
        mark = "✓" if passed else "✗"
        print(f"  {c}[{mark}]{RESET} {label}")
        if passed:
            score += 1

    is_common = pwd.lower() in COMMON_PASSWORDS
    if is_common:
        print(f"  {RED}[!]{RESET} PASSWORD IS IN COMMON LIST - EXTREMELY WEAK")
        score = 0

    section("Entropy & Score")
    print(f"  {GREEN}Charset size:{RESET} {charset_size}")
    print(f"  {GREEN}Length:{RESET}       {length}")
    print(f"  {GREEN}Entropy:{RESET}      {entropy:.1f} bits")

    if is_common or entropy < 28:
        rating, color = "VERY WEAK",   RED
    elif entropy < 40:
        rating, color = "WEAK",        RED
    elif entropy < 60:
        rating, color = "FAIR",        YELLOW
    elif entropy < 80:
        rating, color = "STRONG",      GREEN
    else:
        rating, color = "VERY STRONG", GREEN

    print(f"\n  {color}Rating: {rating}{RESET}")
    if rating in ("VERY WEAK", "WEAK"):
        warn("Consider a longer password with mixed character types.")
