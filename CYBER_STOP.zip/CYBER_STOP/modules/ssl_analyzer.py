name = "SSL/TLS Analyzer"

def run():
    import ssl
    import socket
    import datetime
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, validate_domain, prompt_save

    banner("SSL/TLS ANALYZER", CYAN)
    print(f"  {CYAN}Inspect certificate chain, expiry, cipher suites, and SANs.{RESET}\n")

    host = get_input("Enter hostname (e.g. example.com)")
    if host is None:
        return
    host = host.strip().replace("https://", "").replace("http://", "").split("/")[0]
    port_str = get_input("Port (default 443)", required=False) or "443"
    try:
        port = int(port_str)
    except ValueError:
        port = 443

    lines = [f"SSL/TLS ANALYSIS: {host}:{port}", "=" * 50]
    section(f"Connecting to {host}:{port}...")

    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=10) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
                version = ssock.version()

        section("Protocol & Cipher")
        print(f"  {GREEN}TLS Version:{RESET}  {version}")
        print(f"  {GREEN}Cipher:{RESET}       {cipher[0]}")
        print(f"  {GREEN}Bits:{RESET}         {cipher[2]}")
        lines.extend([f"TLS Version: {version}", f"Cipher: {cipher[0]} ({cipher[2]} bits)"])

        section("Certificate Details")
        subject = dict(x[0] for x in cert.get("subject", []))
        issuer  = dict(x[0] for x in cert.get("issuer", []))
        not_before = cert.get("notBefore", "N/A")
        not_after  = cert.get("notAfter",  "N/A")

        try:
            exp = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
            days_left = (exp - datetime.datetime.utcnow()).days
            exp_str = f"{not_after} ({days_left} days remaining)"
            if days_left < 30:
                warn(f"Certificate expires soon: {exp_str}")
            elif days_left < 0:
                error(f"Certificate EXPIRED: {exp_str}")
            else:
                success(f"Certificate valid for {days_left} more days")
        except Exception:
            exp_str = not_after
            days_left = "?"

        fields = [
            ("Subject CN",    subject.get("commonName", "N/A")),
            ("Issuer",        issuer.get("organizationName", "N/A")),
            ("Valid From",    not_before),
            ("Valid Until",   exp_str),
        ]
        for label, val in fields:
            print(f"  {GREEN}{label:<14}{RESET}: {val}")
            lines.append(f"{label}: {val}")

        section("Subject Alternative Names (SANs)")
        sans = cert.get("subjectAltName", [])
        for stype, sval in sans:
            print(f"  {GREEN}{stype:<8}{RESET} {sval}")
        lines.append("SANs: " + ", ".join(v for _, v in sans))

    except ssl.SSLCertVerificationError as e:
        error(f"SSL Certificate Verification Failed: {e}")
    except ConnectionRefusedError:
        error(f"Connection refused on port {port}")
    except Exception as e:
        error(f"SSL analysis failed: {e}")

    prompt_save("\n".join(lines), "ssl_analysis")
