name = "Exif Metadata Extractor"

def run():
    import os
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("EXIF METADATA EXTRACTOR", CYAN)
    print(f"  {CYAN}Extract GPS, camera model, software info from image files.{RESET}\n")

    filepath = get_input("Enter image file path (JPEG, PNG, TIFF)")
    if filepath is None:
        return
    filepath = filepath.strip().strip('"').strip("'")
    if not os.path.isfile(filepath):
        error(f"File not found: {filepath}")
        return

    lines = [f"EXIF DATA: {filepath}", "=" * 60]

    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS

        img = Image.open(filepath)
        section("Basic Image Info")
        print(f"  {GREEN}Format:{RESET}  {img.format}")
        print(f"  {GREEN}Mode:{RESET}    {img.mode}")
        print(f"  {GREEN}Size:{RESET}    {img.size[0]}x{img.size[1]} px")
        lines.extend([f"Format: {img.format}", f"Size: {img.size[0]}x{img.size[1]}"])

        exif_data = img._getexif()
        if not exif_data:
            warn("No EXIF data found in this image.")
            return

        section("EXIF Tags")
        gps_info = {}
        for tag_id, value in exif_data.items():
            tag = TAGS.get(tag_id, str(tag_id))
            if tag == "GPSInfo":
                for gtag_id, gval in value.items():
                    gtag = GPSTAGS.get(gtag_id, str(gtag_id))
                    gps_info[gtag] = gval
            else:
                if isinstance(value, bytes):
                    try:
                        value = value.decode("utf-8", errors="replace")
                    except Exception:
                        value = repr(value)
                val_str = str(value)[:120]
                print(f"  {GREEN}{tag:<30}{RESET}: {val_str}")
                lines.append(f"{tag}: {val_str}")

        if gps_info:
            section("GPS Information")
            def dms_to_decimal(dms, ref):
                d = float(dms[0])
                m = float(dms[1])
                s = float(dms[2])
                dec = d + m/60 + s/3600
                if ref in ("S", "W"):
                    dec = -dec
                return dec
            try:
                lat = dms_to_decimal(gps_info["GPSLatitude"], gps_info.get("GPSLatitudeRef", "N"))
                lon = dms_to_decimal(gps_info["GPSLongitude"], gps_info.get("GPSLongitudeRef", "E"))
                print(f"  {GREEN}Latitude:{RESET}  {lat:.6f}")
                print(f"  {GREEN}Longitude:{RESET} {lon:.6f}")
                print(f"  {GREEN}Maps URL:{RESET}  https://maps.google.com/?q={lat},{lon}")
                lines.extend([f"GPS Lat: {lat:.6f}", f"GPS Lon: {lon:.6f}",
                               f"Maps: https://maps.google.com/?q={lat},{lon}"])
            except Exception:
                for k, v in gps_info.items():
                    print(f"  {GREEN}{k:<20}{RESET}: {v}")

    except ImportError:
        error("Pillow not installed. Run: pip install pillow")
    except Exception as e:
        error(f"Failed to extract EXIF: {e}")

    prompt_save("\n".join(lines), "exif_data")
