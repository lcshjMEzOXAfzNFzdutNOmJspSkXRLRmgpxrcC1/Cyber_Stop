name = "Port Scanner"

COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 111: "RPC", 135: "MSRPC", 139: "NetBIOS",
    143: "IMAP", 161: "SNMP", 194: "IRC", 443: "HTTPS", 445: "SMB",
    465: "SMTPS", 587: "Submission", 631: "IPP", 993: "IMAPS", 995: "POP3S",
    1080: "SOCKS", 1433: "MSSQL", 1521: "Oracle", 2049: "NFS",
    2181: "Zookeeper", 3306: "MySQL", 3389: "RDP", 4444: "Metasploit",
    5432: "PostgreSQL", 5900: "VNC", 5985: "WinRM", 6379: "Redis",
    6443: "Kubernetes", 7001: "WebLogic", 8080: "HTTP-Alt", 8443: "HTTPS-Alt",
    8888: "Jupyter", 9200: "Elasticsearch", 9300: "Elasticsearch-Cluster",
    27017: "MongoDB", 27018: "MongoDB-Shard",
}

def run():
    import socket
    import threading
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, RED, YELLOW, RESET
    from utils.helpers import get_input, validate_ip, prompt_save

    banner("PORT SCANNER", CYAN)
    print(f"  {CYAN}TCP connect scan. Specify target and port range.{RESET}\n")

    target = get_input("Enter target IP or hostname")
    if target is None:
        return

    range_input = get_input("Port range (e.g. 1-1024 or 'common' for common ports)", required=False)
    if range_input is None:
        return

    timeout_val = 1.0
    lines = [f"PORT SCAN: {target}", "=" * 50]
    open_ports = []
    lock = threading.Lock()

    def scan_port(port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout_val)
                result = s.connect_ex((target, port))
                if result == 0:
                    service = COMMON_PORTS.get(port, "Unknown")
                    with lock:
                        open_ports.append((port, service))
                        print(f"  {GREEN}[OPEN]{RESET}   Port {port:<6} {service}")
        except Exception:
            pass

    if not range_input or range_input.strip().lower() == "common":
        ports = list(COMMON_PORTS.keys())
        section(f"Scanning {len(ports)} common ports on {target}...")
    else:
        try:
            parts = range_input.strip().split("-")
            if len(parts) == 2:
                start, end = int(parts[0]), int(parts[1])
            else:
                start = end = int(parts[0])
            ports = list(range(start, end + 1))
            section(f"Scanning ports {start}-{end} on {target}...")
        except ValueError:
            error("Invalid port range. Use format: 1-1024")
            return

    threads = []
    for port in ports:
        t = threading.Thread(target=scan_port, args=(port,), daemon=True)
        threads.append(t)

    BATCH = 100
    for i in range(0, len(threads), BATCH):
        batch = threads[i:i+BATCH]
        for t in batch:
            t.start()
        for t in batch:
            t.join()

    open_ports.sort()
    print(f"\n  {GREEN}Open ports: {len(open_ports)}{RESET} of {len(ports)} scanned")
    for port, service in open_ports:
        lines.append(f"OPEN  {port} ({service})")

    if not open_ports:
        warn("No open ports found.")

    prompt_save("\n".join(lines), "port_scan")
