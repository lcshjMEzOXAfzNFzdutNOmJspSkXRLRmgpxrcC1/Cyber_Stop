name = "Wayback Machine URLs"

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save, http_get

    banner("WAYBACK MACHINE URLs", CYAN)
    print(f"  {CYAN}Retrieve all historically archived URLs for a domain.{RESET}\n")

    domain = get_input("Enter domain (e.g. example.com)")
    if domain is None:
        return
    domain = domain.strip().lower().replace("https://", "").replace("http://", "").split("/")[0]
    limit_str = get_input("Max results (default 200)", required=False) or "200"
    try:
        limit = int(limit_str)
    except ValueError:
        limit = 200

    section(f"Querying Wayback CDX API for: {domain}")
    url = (
        f"http://web.archive.org/cdx/search/cdx"
        f"?url={domain}/*&output=json&fl=original,timestamp,statuscode&limit={limit}&collapse=urlkey"
    )
    r = http_get(url, timeout=30)
    if not r or r.status_code != 200:
        error("Failed to reach Wayback Machine API.")
        return

    try:
        data = r.json()
    except Exception:
        error("Failed to parse Wayback response.")
        return

    if len(data) <= 1:
        warn("No archived URLs found for this domain.")
        return

    lines = [f"WAYBACK MACHINE: {domain}", "=" * 50]
    headers = data[0]
    entries = data[1:]

    success(f"Found {len(entries)} archived URLs")
    print()

    for entry in entries:
        row = dict(zip(headers, entry))
        url_val = row.get("original", "")
        ts      = row.get("timestamp", "")
        status  = row.get("statuscode", "")
        color   = GREEN if status == "200" else YELLOW
        print(f"  {color}[{status}]{RESET} {ts[:8]} {url_val}")
        lines.append(f"[{status}] {ts} {url_val}")

    prompt_save("\n".join(lines), "wayback_urls")
