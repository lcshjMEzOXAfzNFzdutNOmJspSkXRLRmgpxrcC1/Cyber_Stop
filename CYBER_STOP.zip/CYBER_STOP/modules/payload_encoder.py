name = "Payload Encoder"

import base64
import urllib.parse

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("PAYLOAD ENCODER", CYAN)
    print(f"  {CYAN}Encode payloads for web shells, reverse shells, bypasses.{RESET}")
    print(f"  {YELLOW}[!] Educational use only on systems you own / have permission.{RESET}\n")

    print("  Formats:")
    formats = {
        "1": ("Base64",        lambda c: base64.b64encode(c.encode()).decode()),
        "2": ("URL Encode",    lambda c: urllib.parse.quote(c)),
        "3": ("Double URL",    lambda c: urllib.parse.quote(urllib.parse.quote(c))),
        "4": ("Hex",           lambda c: c.encode().hex()),
        "5": ("HTML Entities", lambda c: "".join(f"&#{ord(ch)};" for ch in c)),
        "6": ("PowerShell B64",lambda c: base64.b64encode(c.encode("utf-16-le")).decode()),
        "7": ("Bash $'...'",   lambda c: "".join(f"\\x{b:02x}" for b in c.encode())),
    }

    for k, (name, _) in formats.items():
        print(f"    [{k}] {name}")

    choice = get_input("Select encoding format")
    if choice not in formats:
        error("Invalid choice.")
        return

    fmt_name, encoder = formats[choice]
    cmd = get_input("Enter command / payload to encode")
    if cmd is None:
        return

    try:
        result = encoder(cmd)
    except Exception as e:
        error(f"Encoding failed: {e}")
        return

    section(f"{fmt_name} Encoded Result")
    print(f"\n  {GREEN}{result}{RESET}\n")

    if choice == "6":
        ps_cmd = f"powershell -encodedcommand {result}"
        print(f"  {YELLOW}PowerShell one-liner:{RESET}")
        print(f"  {ps_cmd}\n")

    prompt_save(result, "payload_encoded")
