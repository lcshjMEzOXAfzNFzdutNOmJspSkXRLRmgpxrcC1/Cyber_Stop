name = "Domain WHOIS"

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, validate_domain, prompt_save

    banner("DOMAIN WHOIS", CYAN)
    print(f"  {CYAN}Fetch registrar, creation/expiry, nameservers, and raw WHOIS.{RESET}\n")

    domain = get_input("Enter domain (e.g. example.com)")
    if domain is None:
        return

    domain = domain.strip().lower().replace("https://", "").replace("http://", "").split("/")[0]

    section(f"Querying WHOIS for: {domain}")

    lines = [f"WHOIS LOOKUP: {domain}", "=" * 50]

    try:
        import whois as pythonwhois
        w = pythonwhois.whois(domain)
        fields = {
            "Domain Name":     w.get("domain_name"),
            "Registrar":       w.get("registrar"),
            "Created":         w.get("creation_date"),
            "Updated":         w.get("updated_date"),
            "Expires":         w.get("expiration_date"),
            "Name Servers":    w.get("name_servers"),
            "Status":          w.get("status"),
            "Emails":          w.get("emails"),
            "Registrant":      w.get("name"),
            "Org":             w.get("org"),
            "Country":         w.get("country"),
        }
        for label, val in fields.items():
            if val:
                if isinstance(val, list):
                    val = ", ".join(str(v) for v in val[:5])
                print(f"  {GREEN}{label:<16}{RESET}: {val}")
                lines.append(f"{label}: {val}")
        success("WHOIS lookup complete.")
    except ImportError:
        warn("'python-whois' not installed. Falling back to socket WHOIS.")
        _raw_whois(domain, lines)
    except Exception as e:
        warn(f"python-whois failed: {e}. Trying raw socket...")
        _raw_whois(domain, lines)

    prompt_save("\n".join(lines), "whois")


def _raw_whois(domain, lines):
    import socket
    from utils.colors import success, error, CYAN, RESET
    try:
        tld = domain.split(".")[-1]
        server = f"whois.iana.org"
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(10)
            s.connect((server, 43))
            s.sendall((domain + "\r\n").encode())
            raw = b""
            while True:
                chunk = s.recv(4096)
                if not chunk:
                    break
                raw += chunk
        text = raw.decode("utf-8", errors="replace")
        refer = None
        for line in text.splitlines():
            if line.lower().startswith("refer:"):
                refer = line.split(":", 1)[1].strip()
                break
        if refer:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s2:
                s2.settimeout(10)
                s2.connect((refer, 43))
                s2.sendall((domain + "\r\n").encode())
                raw2 = b""
                while True:
                    chunk = s2.recv(4096)
                    if not chunk:
                        break
                    raw2 += chunk
            text = raw2.decode("utf-8", errors="replace")
        print(f"\n{CYAN}--- RAW WHOIS ---{RESET}")
        for line in text.splitlines()[:60]:
            print(f"  {line}")
        lines.append(text[:3000])
        success("Raw WHOIS retrieved.")
    except Exception as e:
        from utils.colors import error as err
        err(f"Raw WHOIS failed: {e}")
