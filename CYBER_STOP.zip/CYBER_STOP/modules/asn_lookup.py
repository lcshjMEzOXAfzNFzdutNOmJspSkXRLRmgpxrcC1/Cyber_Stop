name = "ASN Lookup"

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, validate_ip, prompt_save, http_get

    banner("ASN LOOKUP", CYAN)
    print(f"  {CYAN}Retrieve Autonomous System Number, org, and IP blocks.{RESET}\n")

    target = get_input("Enter IP address or ASN (e.g. 8.8.8.8 or AS15169)")
    if target is None:
        return

    lines = [f"ASN LOOKUP: {target}", "=" * 50]

    section("Querying ipinfo.io...")
    if target.upper().startswith("AS"):
        url = f"https://ipinfo.io/{target}/json"
    else:
        url = f"https://ipinfo.io/{target}/json"

    r = http_get(url, timeout=10)
    if r and r.status_code == 200:
        try:
            data = r.json()
            fields = ["ip", "hostname", "city", "region", "country", "org", "postal", "timezone"]
            for f in fields:
                val = data.get(f, "N/A")
                print(f"  {GREEN}{f.title():<12}{RESET}: {val}")
                lines.append(f"{f}: {val}")
        except Exception:
            error("Failed to parse response.")
    else:
        error("ipinfo.io query failed.")

    section("Querying bgpview.io for prefixes...")
    if validate_ip(target):
        url2 = f"https://api.bgpview.io/ip/{target}"
        r2 = http_get(url2, timeout=10)
        if r2 and r2.status_code == 200:
            try:
                d2 = r2.json().get("data", {})
                prefixes = d2.get("prefixes", [])
                for p in prefixes[:5]:
                    print(f"  {GREEN}Prefix:{RESET} {p.get('prefix')}  ASN: AS{p.get('asn',{}).get('asn')} - {p.get('asn',{}).get('name')}")
                    lines.append(f"Prefix: {p.get('prefix')} | ASN: {p.get('asn',{}).get('asn')}")
            except Exception:
                pass

    prompt_save("\n".join(lines), "asn_lookup")
