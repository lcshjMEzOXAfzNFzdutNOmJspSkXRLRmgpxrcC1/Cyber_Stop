name = "Password Generator"

import random
import string
import math

def run():
    from utils.colors import banner, section, success, error, info, warn, CYAN, GREEN, YELLOW, RESET
    from utils.helpers import get_input, prompt_save

    banner("PASSWORD GENERATOR", CYAN)
    print(f"  {CYAN}Generate strong passwords with entropy estimation.{RESET}\n")

    try:
        length = int(get_input("Length (default 16)", required=False) or "16")
        count  = int(get_input("How many passwords? (default 5)", required=False) or "5")
    except ValueError:
        error("Invalid number.")
        return

    print()
    upper   = input("  Include UPPERCASE? [Y/n]: ").strip().lower() != "n"
    lower   = input("  Include lowercase? [Y/n]: ").strip().lower() != "n"
    digits  = input("  Include digits?    [Y/n]: ").strip().lower() != "n"
    symbols = input("  Include symbols?   [Y/n]: ").strip().lower() != "n"

    charset = ""
    if upper:   charset += string.ascii_uppercase
    if lower:   charset += string.ascii_lowercase
    if digits:  charset += string.digits
    if symbols: charset += string.punctuation

    if not charset:
        error("No character set selected!")
        return

    entropy = length * math.log2(len(charset))

    section("Generated Passwords")
    passwords = []
    for i in range(count):
        pwd = "".join(random.SystemRandom().choice(charset) for _ in range(length))
        passwords.append(pwd)
        print(f"  {GREEN}[{i+1}]{RESET} {pwd}")

    print(f"\n  {YELLOW}Charset size:{RESET}   {len(charset)} characters")
    print(f"  {YELLOW}Entropy:{RESET}        {entropy:.1f} bits")

    if entropy < 40:
        warn("Low entropy! Consider longer length or more character types.")
    elif entropy < 60:
        info("Moderate entropy. Adequate for most purposes.")
    else:
        success(f"High entropy ({entropy:.0f} bits). Excellent password strength!")

    output = "\n".join(passwords)
    prompt_save(output, "passwords")
